@echo off
chcp 65001 >nul
title YiTracker 環境安裝與啟動精靈

echo ========================================================
echo         YiTracker 科研級運動追蹤分析工具
echo           自動化環境配置與啟動腳本
echo ========================================================
echo.

:: 1. 檢查是否已安裝 Python
echo [1/4] 檢查 Python 環境...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [錯誤] 找不到 Python！
    echo 請先安裝 Python (建議 3.10 以上版本)，
    echo 並在安裝時務必勾選「Add Python to PATH」選項。
    echo.
    pause
    exit /b
)
python --version
echo Python 環境正常。
echo.

:: 2. 升級 pip
echo [2/4] 更新 pip 工具...
python -m pip install --upgrade pip
echo.

:: 3. 自動安裝專案所需依賴套件
echo [3/4] 檢查並安裝必要依賴套件 (OpenCV, Matplotlib, Pandas, SciPy, Pillow)...
:: 注意：Tracker 演算法包含在 opencv-contrib-python 中
python -m pip install opencv-contrib-python pillow pandas numpy matplotlib scipy
if %errorlevel% neq 0 (
    echo.
    echo [警告] 部分套件安裝可能出現問題，請檢查網路連線。
    pause
) else (
    echo 所有依賴套件安裝/更新完成！
)
echo.

:: 4. 尋找主程式並啟動
echo [4/4] 正在啟動 YiTracker...

:: 優先檢查常見的命名
if exist "main.py" (
    python main.py
) else if exist "tracker.py" (
    python tracker.py
) else if exist "tracker - 複製.py" (
    python "tracker - 複製.py"
) else (
    echo [錯誤] 找不到 Python 主程式檔 (例如 main.py 或 tracker.py)！
    echo 請確認本 .bat 檔與你的 .py 程式碼放在同一個資料夾。
    pause
    exit /b
)

echo.
echo 程式已結束。
pause